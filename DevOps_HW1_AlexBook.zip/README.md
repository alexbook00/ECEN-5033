# Homework 1, ECEN 5033

## How to run
You will need to install vagrant, directions can be found [here](https://www.vagrantup.com/downloads). You will also need a VM that is supported by Vagrant, information can be found [here](https://www.vagrantup.com/docs/providers).


Once the above requirements have been met, simply run the following command from within the main project directory:

```
$ vagrant up
```
