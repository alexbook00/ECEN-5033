docker build -t custom-nginx .
